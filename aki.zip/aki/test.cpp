#include <cstdio>
#include <iostream>

struct node {

	char * data1;
};
 
int main()
{
  FILE * ptrFile = fopen("file.txt", "r");
 
  //char buffer [256];

  /*
 
  if (ptrFile == NULL) perror("Ошибка открытия файла");
  else
  {
    while ( !feof(ptrFile) )             // пока не конец файла
    {
      int c = getc(ptrFile);             // считать символ из файла
 
      if (c == '%')                    // если считанный символ - %
        ungetc('~', ptrFile);            // вернуть символ '~' в поток ввода
    fflush (ptrFile);
 
      fgets(buffer, 255, ptrFile);       // считать символы из файла и сохранить в buffer
      fputs(buffer, stdout);           // вывод на экран содержимого буфера
    }
 
    fclose(ptrFile);
  }

  */

  /*

  char buffer [100] = "        dflsd  sad";
  char capacityBuffer [100] = " ";
  int val = 0;
  sscanf (buffer, "%s%n", capacityBuffer, &val);

  printf ("buffer: %s\nval: %d\n", capacityBuffer, val);

  */


  char data [100] = "Hello, world";
  node n = {};
  n.data1 = (char * ) calloc (100, sizeof (char));
  n.data1 = data;

  puts (n.data1);
 
  return 0;
}