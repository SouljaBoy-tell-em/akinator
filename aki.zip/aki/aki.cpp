#include "aki_head_stack.h"
#include "head_aki.h"
#include "aki.h"
#include "aki_stack.h"


int main (void) {

	CHECK_ERROR(Aki (), "Problem with function Aki ()");

	return ERROR_OFF;
}
